install.packages("ggplot2")
library(ggplot2)
data <- read.csv("done.csv",sep = ",",header = T) 
data <- data[,2:8]
data <- subset(data,LS=="1" |LS=="3" )
# scale. = TRUE表示分析前对数据进行归一化；
com1 <- prcomp(data[,1:6], center = TRUE,scale. = TRUE)
summary(com1)
#提取PC score；
df1<-com1$x
head(df1)
#将iris数据集的第5列数据合并进来；
df1<-data.frame(df1,data$LS)
head(df1)
#提取主成分的方差贡献率，生成坐标轴标题；
summ<-summary(com1)

xlab<-paste0("PC1(",round(summ$importance[2,1]*100,2),"%)")
ylab<-paste0("PC2(",round(summ$importance[2,2]*100,2),"%)")
p2<-ggplot(data = df1,aes(x=PC1,y=PC2,color=as.factor(data.LS)))+
  stat_ellipse(aes(fill=as.factor(data.LS)),
               type = "norm", geom ="polygon",alpha=0.2,color=NA)+
  geom_point()+labs(x=xlab,y=ylab,color="")+
  guides(fill=F)
p2+scale_fill_manual(values = c("blue","#f0027f"))+
  scale_colour_manual(values = c("blue","#f0027f"))
"#ffff99", 


rm(list = ls())
data <- read.csv("done.csv",sep = ",",header = T) 
data <- data[,2:8]
data <- subset(data,LS=="1" |LS=="3" )
dt<-as.matrix(scale(data[,1:6]))
head(dt)
rm1<-cor(dt)
rm1
rs1<-eigen(rm1)
rs1
#提取结果中的特征值，即各主成分的方差；
val <- rs1$values
#换算成标准差(Standard deviation);
(Standard_deviation <- sqrt(val))
#计算方差贡献率和累积贡献率；
(Proportion_of_Variance <- val/sum(val))
(Cumulative_Proportion <- cumsum(Proportion_of_Variance))
